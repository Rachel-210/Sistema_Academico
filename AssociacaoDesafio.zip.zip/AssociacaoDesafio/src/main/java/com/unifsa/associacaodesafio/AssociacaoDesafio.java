package com.unifsa.associacaodesafio;

public class AssociacaoDesafio {

    public static void main(String[] args) {
        Associado a1 = new Associado(
            1, "Breno Silva", "Rua das Flores", "123", "90000-000", 
            "Centro", "Porto Alegre", "RS", "(51) 9999-8888", 
            "123.456.789-10", "Ativo", 1001
        );

        Colaborador c1 = new Colaborador(
            2, "Ana Souza", "Av. Brasil", "456", "66000-000", 
            "Umarizal", "Belém", "PA", "(91) 9888-7777", 
            "987.654.321-00", "Gerente Farmacêutica"
        );

        Fornecedor f1 = new Fornecedor(
            3, "Distribuidora Saúde Ltda", "Rua do Comércio", "789", "40000-000", 
            "Comércio", "Salvador", "BA", "(71) 3333-2222", 
            "12.345.678/0001-99", "Saúde Total", "www.saudetotal.com.br"
        );

        System.out.println("\nDADOS DO ASSOCIADO:");
        System.out.println("ID: " + a1.getId());
        System.out.println("Nome: " + a1.getNome());
        System.out.println("Endereço: " + a1.getLogradouro() + ", " + a1.getNumero());
        System.out.println("CEP: " + a1.getCep() + " | Bairro: " + a1.getBairro());
        System.out.println("Cidade: " + a1.getCidade() + "/" + a1.getUf());
        System.out.println("Telefone: " + a1.getTelefone());
        System.out.println("CPF/CNPJ: " + a1.getCpfCnpj());
        System.out.println("Situação: " + a1.getSituacao());
        System.out.println("Número do Associado: " + a1.getNumeroAssociado());

        System.out.println("\nDADOS DO COLABORADOR:");
        System.out.println("ID: " + c1.getId());
        System.out.println("Nome: " + c1.getNome());
        System.out.println("Cargo/Função: " + c1.getCargo());
        System.out.println("CPF/CNPJ: " + c1.getCpfCnpj());
        System.out.println("Telefone: " + c1.getTelefone());
        System.out.println("Endereço Completo: " + c1.getLogradouro() + ", " + c1.getNumero() + " - " + c1.getCidade());

        System.out.println("\nDADOS DO FORNECEDOR:");
        System.out.println("ID: " + f1.getId());
        System.out.println("Razão Social: " + f1.getNome());
        System.out.println("Nome Fantasia: " + f1.getNomeFantasia());
        System.out.println("Website: " + f1.getWebsite());
        System.out.println("CNPJ: " + f1.getCpfCnpj());
        System.out.println("Contato: " + f1.getTelefone());
        System.out.println("Localização: " + f1.getLogradouro() + ", " + f1.getNumero() + " - " + f1.getBairro());
    }
}
